<?php $this->load->view('load/head'); ?>
<?php $this->load->view('load/sign_up'); ?>
<?php $this->load->view('load/main'); ?>
<?php $this->load->view('load/foot'); ?>