<div class="mFoot">
		<div class="col-md-12">
			<div class="container wow fadeInUp">
				<center style="margin-top:-20px;margin-bottom:-20px;">
					<p>Gas Alam No.B46 RT04/007<br>Curug, Cimanggis, Kota Depok 16453</p>
					<ul class="" style="list-style:none;padding:0;">
						<li><i class="fa fa-phone"></i> +61 123 456 7890</li>
						<li><i class="fa fa-envelope-o"></i><a href="mailto:hello@sofensys.com"> hellomybarber@gmail.com</a></li>
					</ul>
					<div class="sosmed">
						<a target="_blank" href="https://facebook.com" class="fac"><i class="fa-facebook fa"></i></a>
						<a target="_blank" href="https://twitter.com" class="twit"><i class="fa-twitter fa"></i></a>
						<a target="_blank" href="https://plus.google.com" class="gplus"><i class="fa-google-plus fa"></i></a>
					</div>
					<label style="border-top:solid 1px #999;width:15%;margin-top:18px;"></label>
					<p style="margin:0;">Copyright &copy; 2019<br> All Right Reserved</p>
				</center>
			</div>
		</div>
	</div>
<script type="text/javascript" src="<?php echo base_url(); ?>dist/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>dist/js/bootstrap.min.js"></script>
<!-- <script type="text/javascript" src="<?php echo base_url(); ?>dist/js/owl.carousel.js"></script> -->
<script type="text/javascript" src="<?php echo base_url(); ?>dist/js/wow.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>dist/js/smooth-scroll.js"></script>
<script src="<?php echo base_url(); ?>dist/preloader/js/classie.js"></script>
<script src="<?php echo base_url(); ?>dist/preloader/js/pathLoader.js"></script>
<script src="<?php echo base_url(); ?>dist/preloader/js/main.js"></script>
<script  type="text/javascript">
	wow = new WOW(
	{
		animateClass: 'animated',
		offset:       100,
	}
	);
	wow.init();
	
</script>
</body>
</html>
