
<div style="background:url(<?php echo base_url('dist/img/tweed.png'); ?>);padding-top:0px;padding:50px 0;">
		<div class="container">
			<center class="wow fadeInDown">
				<h1 style="color:#fff;">Mengapa Harus Menggunakan Jasa Kami?</h1>
				<label class="" style="border-top:solid 3px #999;width:70px;"></label>
				<p style="color:#fff;">MyBarber adalah aplikasi yang menyediakan antrian cukur rambut dengan banyak kelebihan</p>				
			</center>
			<div class="col-md-12">
				<center>
					<div class="row">
						<div class="col-md-4 wow fadeInLeft">
							<div class="panel panel-default mypan">
								<div class="panel-body" style="background:#4b4b4b;">
									<i style="font-size:2em; color:#fff;" class="glyphicon glyphicon-flash"></i>
									<h2 style="color:#fff;">Cepat</h2>
									<p style="color:#fff;"><label>MyBarber</label> menjamin kecepatan dan ketepatan sistem kami untuk antrian Anda.</p>
								</div>
							</div>
						</div>
						<div class="col-md-4 wow fadeInUp">
							<div class="panel panel-default mypan">
								<div class="panel-body" style="background:#4b4b4b;">
									<i style="font-size:2em; color:#fff;" class="glyphicon glyphicon-ok"></i>
									<h2 style="color:#fff;">Mudah</h2>
									<p style="color:#fff;">Dengan <label>MyBarber</label> anda menjadi lebih mudah dalam menggunakan jasa mencukur rambut.</p>
								</div>
							</div>
						</div>
						<div class="col-md-4 wow fadeInRight">
							<div class="panel panel-default mypan">
								<div class="panel-body" style="background:#4b4b4b;">
									<i style="font-size:2em; color:#fff;" class="glyphicon glyphicon-lock"></i>
									<h2 style="color:#fff;">Aman</h2>
									<p style="color:#fff;"><label>MyBarber</label> menjamin keamanan segala data informasi yang Anda masukan di <label>MyBarber</label>.</p>
								</div>
							</div>
						</div>
					</div>
				</center>
			</div>

		</div>
	</div>



<div style="background:url(<?php echo base_url('dist/img/mooning.png'); ?>);padding-top:0px;padding:20px 0;">
<div class="container" style="width:100%;height:100%;">
    <div class="col-md-12">
    <center class="wow bounceInDown"><h1 style="color:#000;font-family: 'Avenir Next';font-size: 2em;" class="titleMenu">LIHAT KAMI LEBIH DEKAT</h1>
    <label class="" style="border-top:solid 3px #000;width:400px;margin-bottom:30px;"></label>
    </center>   
        <div class="well" style="background:#676561;">
            <div id="myCarousel" class="carousel slide" style="margin-top:20px;">
                
                <!-- Carousel items -->
                <div class="carousel-inner">
                    <div class="item active">
                        <div class="row">
                            <div class="col-sm-3" ><img style="height:250px;" src="<?php echo base_url('dist/img/th2.jpg'); ?>" alt="Image" class="img-responsive thumbnail">
                            </div>
                            <div class="col-sm-3"><img style="height:250px;" src="<?php echo base_url('dist/img/th1.jpg'); ?>" alt="Image" class="img-responsive thumbnail">
                            </div>
                            <div class="col-sm-3"><img style="height:250px;" src="<?php echo base_url('dist/img/th3.jpg'); ?>" alt="Image" class="img-responsive thumbnail">
                            </div>
                            <div class="col-sm-3"><img style="height:250px;" src="<?php echo base_url('dist/img/bg2.jpg'); ?>" alt="Image" class="img-responsive thumbnail">
                            </div>
                        </div>
                        <!--/row-->
                    </div>
                    <!--/item-->
                    <div class="item">
                        <div class="row">
                            <div class="col-sm-3"><img style="height:250px;" src="<?php echo base_url('dist/img/th4.jpg'); ?>" alt="Image" class="img-responsive thumbnail">
                            </div>
                            <div class="col-sm-3"><img style="height:250px;" src="<?php echo base_url('dist/img/th5.jpg'); ?>" alt="Image" class="img-responsive thumbnail">
                            </div>
                            <div class="col-sm-3"><img style="height:250px;" src="<?php echo base_url('dist/img/th6.jpg'); ?>" alt="Image" class="img-responsive thumbnail">
                            </div>
                            <div class="col-sm-3"><img style="height:250px;" src="<?php echo base_url('dist/img/th7.jpg'); ?>" alt="Image" class="img-responsive thumbnail">
                            </div>
                        </div>
                        <!--/row-->
                    </div>
                    <!--/item-->
                </div>
                <!--/carousel-inner--> 
                <a class="left carousel-control" style="width:10%; margin-bottom:20px;" href="#myCarousel" data-slide="prev"><h1 style="margin-top:80%;">‹</h1></a>
                <a class="right carousel-control" style="width:10%; margin-bottom:20px;" href="#myCarousel" data-slide="next"><h1 style="margin-top:80%;">›</h1></a>
            </div>
            <!--/myCarousel-->
        </div>
        <!--/well-->
    </div>
</div>
</div>